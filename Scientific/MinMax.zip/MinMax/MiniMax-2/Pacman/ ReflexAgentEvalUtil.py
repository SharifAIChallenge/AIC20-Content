def reflexAgentEval(reflexAgent, gameState, action):
    return 0