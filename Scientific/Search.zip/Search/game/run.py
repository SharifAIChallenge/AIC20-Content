import nq

e = nq.queen(8, 200)
e.makeitrain()

